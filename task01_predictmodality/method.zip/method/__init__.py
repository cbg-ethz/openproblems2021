from .method import main

METHOD_ID = "bewinator"
